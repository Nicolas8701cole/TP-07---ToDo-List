using Newtonsoft.Json;
public class TxU
{
    public int id { get; set; }
     public int idTarea { get; set; }
      public int idUsuario { get; set; }
      public TxU(){}
}